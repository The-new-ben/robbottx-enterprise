=== RobbottX Core ===
Contributors: robbottx
Requires at least: 6.9
Tested up to: 7.0
Requires PHP: 8.3
Stable tag: 0.1.5
License: GPLv2 or later

Source-backed robotics records and compatibility views for RobbottX.

== Description ==

Provides RobbottX robotics record types, manufacturer-published specifications,
compatibility conditions, technical document references, record-integrity
checks, a public status endpoint, and a guarded update-manifest connection.

Compatibility, certification, stock, price, warranty, and regional availability
are shown only when the applicable record contains supporting information.
